package model;

import view.TipoAtendimento;
import view.EspecialidadeMedica;

import javax.swing.JOptionPane;
public class Paciente {
    private String nome;
    private int idade;
    private String senha;
    private TipoAtendimento tipoAtendimento;
    private String especialidade;

    public Paciente(String nome, int idade, String senha, TipoAtendimento tipoAtendimento, String especialidadeMedica) {
        this.nome = nome;
        this.idade = idade;
        this.senha = senha;
        this.tipoAtendimento = tipoAtendimento;
        this.especialidade = especialidadeMedica;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getSenha() {
        return senha;
    }

    public TipoAtendimento getTipoAtendimento() {
        return tipoAtendimento;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public boolean isUrgente() {
        return tipoAtendimento == TipoAtendimento.PREFERENCIAL;
    }
}

class FilaHospitalView {
    public void exibirMensagem(String mensagem) {
        JOptionPane.showMessageDialog(null, mensagem);
    }

    public String obterInput(String mensagem) {
        return JOptionPane.showInputDialog(null, mensagem);
    }
}
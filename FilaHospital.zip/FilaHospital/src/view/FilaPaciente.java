package view;

import model.Paciente;

import java.util.ArrayList;
import java.util.List;

public class FilaPaciente {
    private static FilaPaciente instance;
    private List<Paciente> pacientes;

    private FilaPaciente() {
        pacientes = new ArrayList<>();
    }

    public static FilaPaciente getInstance() {
        if (instance == null) {
            instance = new FilaPaciente();
        }
        return instance;
    }

    public void adicionarPaciente(int posicao, Paciente paciente) {
        pacientes.add(posicao - 1, paciente);
    }

    public int getTamanho() {
        return pacientes.size();
    }
}

package view;

public enum EspecialidadeMedica {
    CLINICO_GERAL,
    CARDIOLOGISTA,
    DERMATOLOGISTA,
    GINECOLOGISTA,
    PEDIATRA
}

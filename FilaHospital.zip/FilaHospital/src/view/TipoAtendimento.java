package view;

public  enum TipoAtendimento {
    PREFERENCIAL,
    NORMAL
}


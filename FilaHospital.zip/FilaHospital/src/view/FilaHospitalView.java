package view;

import controller.FilaHospitalController;
import model.Paciente;

	import javax.swing.JOptionPane;
	

	public class FilaHospitalView<Fila> {

	    public static void main(String[] args) {
	       
	    }

	    public String obterSenhaPaciente() {
	        return JOptionPane.showInputDialog("Digite a senha do paciente:");
	    }

	    public void exibirMensagem(String mensagem) {
	        JOptionPane.showMessageDialog(null, mensagem);
	    }

	    public String obterNomePaciente() {
	        return JOptionPane.showInputDialog("Digite o nome do paciente:");
	    }

	    public int obterIdadePaciente() {
	        return Integer.parseInt(JOptionPane.showInputDialog("Digite a idade do paciente:"));
	    }

	    public String obterEspecialidade() {
	        String[] especialidades = { "Cardiologia", "Dermatologia", "Ginecologia", "Pediatria", "Outra" };
	        int especialidadeSelecionada = JOptionPane.showOptionDialog(null, "Escolha a especialidade:", "Especialidade",
	                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, especialidades, especialidades[0]);

	        return especialidades[especialidadeSelecionada];
	    }

	    public boolean calcularPrioridade(int idade) {
	        return idade >= 60;
	    }

		public TipoAtendimento obterTipoAtendimentoPaciente() {
			// TODO Auto-generated method stub
			return null;
		}

		public String obterInput(String string) {
			// TODO Auto-generated method stub
			return null;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	    

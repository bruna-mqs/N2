package controller;

import model.Paciente;
import view.FilaHospitalView;
import view.TipoAtendimento;

public class main {
    public static void main(String[] args) {
    	Paciente model = new Paciente("Nome",0, "senha", TipoAtendimento.NORMAL, "especialidade");

        FilaHospitalView view = new FilaHospitalView();
    }
}

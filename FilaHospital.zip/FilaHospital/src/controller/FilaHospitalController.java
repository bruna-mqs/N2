package controller;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Random;

import model.Paciente;
import view.EspecialidadeMedica;
import view.TipoAtendimento;
import view.FilaHospitalView;

public class FilaHospitalController {
    private FilaHospitalA filaHospital;

    public FilaHospitalController() {
        filaHospital = new FilaHospitalA();
    }

    public void iniciarAtendimento() {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }

        filaHospital.iniciarAtendimento();
    }

    public static void main(String[] args) {
        FilaHospitalController controller = new FilaHospitalController();
        controller.iniciarAtendimento();
    }
}

class FilaHospitalA {
    private Queue<Paciente> fila;
    private FilaHospitalView view;
    private int pacientesComunsAtendidos;
    private Map<Integer, Paciente> historicoAtendimento;
    private int pacientesComunsAtendidosAntesEncaixe;
    private int pacientesComunsAtendidosDesdeEncaixe;


    public static final int ATENDIMENTOS_COMUNS_PARA_PREFERENCIAL = 3;
    public static final int MAX_PACIENTES = 50;

    public FilaHospitalA() {
        fila = new LinkedList<>();
        view = new FilaHospitalView();
        pacientesComunsAtendidos = 0;
        historicoAtendimento = new HashMap<>();
        pacientesComunsAtendidosAntesEncaixe = 0;
        pacientesComunsAtendidosDesdeEncaixe = 0;
    }

    public void iniciarAtendimento() {
        view.exibirMensagem("Bem-vindo(a) à fila de atendimento do Hospital!");

        while (true) {
            int opcao = exibirMenuPrincipal();

            switch (opcao) {
                case 1:
                    opcaoPaciente();
                    break;
                case 2:
                    opcaoAtendente();
                    break;
                case 3:
                    opcaoMedico();
                    break;
                case 4:
                    return;
                default:
                    view.exibirMensagem("Opção inválida! Tente novamente.");
            }
        }
    }

    private int exibirMenuPrincipal() {
        String[] opcoes = {"Paciente", "Atendente", "Médico", "Sair"};
        int opcaoSelecionada = JOptionPane.showOptionDialog(
                null,
                "Escolha uma opção:",
                "Menu Principal",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opcoes,
                opcoes[0]
        );

        return opcaoSelecionada + 1;
    }

    private void opcaoPaciente() {
        while (true) {
            int opcao = exibirMenuPaciente();

            switch (opcao) {
                case 1:
                    verPosicaoNaFila();
                    break;
                case 2:
                    exibirHistoricoAtendimento();
                    break;
                case 3:
                    return;
                default:
                    view.exibirMensagem("Opção inválida! Tente novamente.");
            }
        }
    }

    private int exibirMenuPaciente() {
        String[] opcoes = {"Ver posição na fila", "Histórico de atendimento", "Sair"};
        int opcaoSelecionada = JOptionPane.showOptionDialog(
                null,
                "Escolha uma opção:",
                "Menu Paciente",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opcoes,
                opcoes[0]
        );

        return opcaoSelecionada + 1;
    }

    private void opcaoAtendente() {
        while (true) {
            int opcao = exibirMenuAtendente();

            switch (opcao) {
                case 1:
                    adicionarPacientePorAtendente();
                    break;
                case 2:
                    exibirHistoricoAtendimento();
                    break;
                case 3:
                    return;
                default:
                    view.exibirMensagem("Opção inválida! Tente novamente.");
            }
        }
    }

    private int exibirMenuAtendente() {
        String[] opcoes = {"Adicionar paciente à fila", "Histórico de atendimento", "Sair"};
        int opcaoSelecionada = JOptionPane.showOptionDialog(
                null,
                "Escolha uma opção:",
                "Menu Atendente",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opcoes,
                opcoes[0]
        );

        return opcaoSelecionada + 1;
    }

    private void opcaoMedico() {
        while (true) {
            int opcao = exibirMenuMedico();

            switch (opcao) {
                case 1:
                    atenderPaciente();
                    break;
                case 2:
                    exibirHistoricoAtendimento();
                    break;
                case 3:
                    return;
                default:
                    view.exibirMensagem("Opção inválida! Tente novamente.");
            }
        }
    }

    private int exibirMenuMedico() {
        String[] opcoes = {"Atender próximo paciente", "Histórico de atendimento", "Sair"};
        int opcaoSelecionada = JOptionPane.showOptionDialog(
                null,
                "Escolha uma opção:",
                "Menu Médico",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opcoes,
                opcoes[0]
        );

        return opcaoSelecionada + 1;
    }

    private void adicionarPacientePorAtendente() {
    	 if (fila.size() < 50) {
    		
       String nome = JOptionPane.showInputDialog(null, "Digite o nome do paciente:");
        int idade = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a idade do paciente:"));
        String senha = gerarSenhaAleatoria();
        TipoAtendimento tipoAtendimento = verificarTipoAtendimento(idade);
        EspecialidadeMedica especialidade = selecionarEspecialidade();
        adicionarPaciente(nome, idade, senha, tipoAtendimento, especialidade);

        if (tipoAtendimento == TipoAtendimento.PREFERENCIAL) {
            pacientesComunsAtendidosAntesEncaixe = 0;
        } else {
            pacientesComunsAtendidosAntesEncaixe++;
        }
                view.exibirMensagem("Paciente " + nome + " adicionado à fila com sucesso!");
            } else {
                view.exibirMensagem("A fila está cheia. Não é possível adicionar mais pacientes.");
            }
        }

    

    private TipoAtendimento verificarTipoAtendimento(int idade) {
        return (idade > 60) ? TipoAtendimento.PREFERENCIAL : TipoAtendimento.NORMAL;
    }

    private String gerarSenhaAleatoria() {
        // Implementação simples de geração de senha aleatória
        return Integer.toString((int) (Math.random() * 10000));
    }

    private EspecialidadeMedica selecionarEspecialidade() {
        String[] especialidades = {
                "Clínico Geral",
                "Cardiologista",
                "Dermatologista",
                "Ginecologista",
                "Pediatra"
        };

        String especialidadeStr = (String) JOptionPane.showInputDialog(
                null,
                "Selecione a especialidade médica:",
                "Especialidade Médica",
                JOptionPane.PLAIN_MESSAGE,
                null,
                especialidades,
                especialidades[0]
        );

        if (especialidadeStr == null) {
            // O usuário cancelou a seleção, retorne um valor padrão
            return EspecialidadeMedica.CLINICO_GERAL;
        } else if (especialidadeStr.equals("Clínico Geral")) {
            return EspecialidadeMedica.CLINICO_GERAL;
        } else if (especialidadeStr.equals("Cardiologista")) {
            return EspecialidadeMedica.CARDIOLOGISTA;
        } else if (especialidadeStr.equals("Dermatologista")) {
            return EspecialidadeMedica.DERMATOLOGISTA;
        } else if (especialidadeStr.equals("Ginecologista")) {
            return EspecialidadeMedica.GINECOLOGISTA;
        } else if (especialidadeStr.equals("Pediatra")) {
            return EspecialidadeMedica.PEDIATRA;
        } else {
            // Valor inválido selecionado, retorne um valor padrão
            return null;
        }
    }
    

    private void adicionarPaciente(String nome, int idade, String senha, TipoAtendimento tipoAtendimento, EspecialidadeMedica especialidade) {
    	String especialidadeMedica = null;
		Paciente paciente = new Paciente(nome, idade, senha, tipoAtendimento, especialidadeMedica);
        fila.add(paciente);
        view.exibirMensagem("Paciente " + nome + " adicionado(a) à fila. Senha: " + senha);
    }

    private void verPosicaoNaFila() {
        if (fila.isEmpty()) {
            JOptionPane.showMessageDialog(null, "A fila de atendimento está vazia.");
            return;
        }

        String senha = JOptionPane.showInputDialog(null, "Informe sua senha:");

        int posicao = 0;
        boolean senhaEncontrada = false;
        for (Paciente paciente : fila) {
            posicao++;
            if (paciente.getSenha().equals(senha)) {
                senhaEncontrada = true;
                JOptionPane.showMessageDialog(null, "Quantidade de pacientes na frente: " + (posicao - 1) +
                        "\nNome: " + paciente.getNome());
                                       break;
            }
        }

        if (!senhaEncontrada) {
            JOptionPane.showMessageDialog(null, "Desculpe, senha informada errada.");
        }
    }



    private void atenderPaciente() {
        if (fila.isEmpty()) {
            view.exibirMensagem("A fila está vazia. Não há pacientes aguardando atendimento.");
        } else {

            if (pacientesComunsAtendidosDesdeEncaixe >= 3) {
                adicionarPacientePreferencialEncaixe();
                pacientesComunsAtendidosDesdeEncaixe = 0; // Reiniciar o contador para 0 após adicionar o paciente preferencial
                return; // Adicionado para interromper o fluxo e evitar a execução do restante do método
            }
            pacientesComunsAtendidosDesdeEncaixe++; // Incremento movido para dentro do bloco 'if'

            Paciente paciente = fila.poll();
            if (historicoAtendimento.size() == 50) {
                Iterator<Map.Entry<Integer, Paciente>> iterator = historicoAtendimento.entrySet().iterator();
                iterator.next(); // Remover o paciente mais antigo do histórico
                iterator.remove();
            }
            historicoAtendimento.put(historicoAtendimento.size() + 1, paciente);

            String mensagemAtendimento = "Nome: " + paciente.getNome() + "\n";
            if (paciente.isUrgente()) {
                mensagemAtendimento += "Tipo de Atendimento: Preferencial\n";
            } else {
                mensagemAtendimento += "Tipo de Atendimento: Normal\n";
            }
            
            view.exibirMensagem(mensagemAtendimento);
        }
    }

    	
    private void adicionarPacientePreferencialEncaixe() {
        Paciente paciente = obterProximoPacientePreferencial();
        if (paciente != null) {
            fila.add(paciente);
            view.exibirMensagem("Paciente preferencial " + paciente.getNome() + " para ser atendido.");
        }
    }

    	  private Paciente obterProximoPacientePreferencial() {
    		    for (Paciente paciente : fila) {
    		        if (paciente.getTipoAtendimento() == TipoAtendimento.PREFERENCIAL) {
    		            fila.remove(paciente);
    		            return paciente;
    		        }
    		    }
    		    return null;
    		}


    	  private void exibirHistoricoAtendimento() {
    	        String historico = "Histórico de atendimento:\n";
    	        for (Map.Entry<Integer, Paciente> entry : historicoAtendimento.entrySet()) {
    	            int numeroAtendimento = entry.getKey();
    	            Paciente paciente = entry.getValue();
    	            historico += "Atendimento " + numeroAtendimento + ": " + paciente.getNome() + " (Idade: " + paciente.getIdade() + ")\n";

    	        }
    	        view.exibirMensagem(historico);
    	    }
    	}

